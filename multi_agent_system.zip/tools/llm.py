def call_llm(prompt):
    # 模拟AI返回
    return f"[AI生成内容]: {prompt}"
