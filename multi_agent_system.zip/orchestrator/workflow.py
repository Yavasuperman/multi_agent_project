from agents.topic_agent import TopicAgent
from agents.script_agent import ScriptAgent
from agents.publish_agent import PublishAgent
from agents.analysis_agent import AnalysisAgent

class Workflow:

    def __init__(self):
        self.topic_agent = TopicAgent("TopicAgent")
        self.script_agent = ScriptAgent("ScriptAgent")
        self.publish_agent = PublishAgent("PublishAgent")
        self.analysis_agent = AnalysisAgent("AnalysisAgent")

    def run(self):
        print("🚀 开始执行多Agent流程")

        topics = self.topic_agent.run("驾校招生")
        print("选题：", topics)

        script = self.script_agent.run(topics)
        print("脚本：", script)

        publish_result = self.publish_agent.run(script)

        analysis = self.analysis_agent.run(None)
        print("数据分析：", analysis)

        return {
            "topics": topics,
            "script": script,
            "publish": publish_result,
            "analysis": analysis
        }
