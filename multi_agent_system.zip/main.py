from orchestrator.workflow import Workflow

if __name__ == "__main__":
    wf = Workflow()
    result = wf.run()

    print("\n最终结果：")
    print(result)
