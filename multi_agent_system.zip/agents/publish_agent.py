from agents.base_agent import BaseAgent

class PublishAgent(BaseAgent):
    def run(self, script):
        print("发布内容：", script)
        return {"status": "published"}
