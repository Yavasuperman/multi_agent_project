from agents.base_agent import BaseAgent
from tools.llm import call_llm

class TopicAgent(BaseAgent):
    def run(self, input_data):
        prompt = f"为驾校生成5个短视频选题：{input_data}"
        return call_llm(prompt)
