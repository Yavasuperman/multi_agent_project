from agents.base_agent import BaseAgent
import random

class AnalysisAgent(BaseAgent):
    def run(self, _):
        return {
            "views": random.randint(1000, 5000),
            "conversion": round(random.uniform(1, 5), 2)
        }
