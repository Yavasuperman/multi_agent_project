from agents.base_agent import BaseAgent
from tools.llm import call_llm

class ScriptAgent(BaseAgent):
    def run(self, topics):
        prompt = f"根据以下选题生成短视频口播脚本：{topics}"
        return call_llm(prompt)
